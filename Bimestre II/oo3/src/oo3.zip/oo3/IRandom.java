package oo3;

// � ABSTRATO
public interface IRandom {
	
	// � ABSTRATO N�O FUNCIONA
	public void next();
	
	public double get();
	// � abstrato
	
}
