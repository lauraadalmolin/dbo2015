package oo3;

// CLASSE CONCRETA
// PiorRadomPossivel � um IRandom
public class PiorRandomPossivel implements IRandom {

	
	// � CONCRETO
	@Override
	public void next() {
		// TODO Auto-generated method stub
		
		
	}
	
	
	// � CONCRETO
	@Override
	public double get() {
		// TODO Auto-generated method stub
		return 0.9;
	}
	
	
	
	
}
