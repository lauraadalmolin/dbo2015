package random;

public class Random implements IRandom {
	
	private long semente;
	private long ret;
	
	public Random() {
		semente = System.currentTimeMillis();
		String s = semente + "";
		char[] a = s.toCharArray();
		String b = "";
		for (int i = a.length - 12; i < a.length; i++) {
			if (a[i] == '0') b =  b + 2;
			else b =  b + a[i];
		}
		semente = Strings.toInt(b);
	}
	
	public void newRandom() {
		semente = System.currentTimeMillis();
		String s = semente + "";
		char[] a = s.toCharArray();
		String b = "";
		for (int i = a.length - 12; i < a.length; i++) {
			if (a[i] == '0') b =  b + 2;
			else b =  b + a[i];
		}
		semente = Strings.toInt(b);
	}
	
	public Random (long s) {
		String a = s + "";
		char[] b = a.toCharArray();
		if (b.length < 12) {
			char[] seed = new char[12];
			int i;
			for (i = 0; i < b.length; i++) seed[i] = b[i];
			for (; i < 12; i++) seed[i] = 7;
		}
		else {
			if (b.length >= 12) {
				String x = "";
				for (int i = 0; i < 12; i++) {
					x =  x + b[i];
				}
				semente = Strings.toInt(x);
			}
		}
	}
	
	/**
     * Gera o pr�ximo n�mero aleat�rio.
     * O valor n�o � alterado at� esse m�todo ser invocado.
     */
	
    public void next() {
    	if (semente > 1000000000000l) {
    		for (; semente > 1000000000000l; semente/=10);
    	}
    	if (semente == 0) this.newRandom(); 
    	String a = semente + "";
    	char[] b = a.toCharArray();
    	char[] seed = new char[6];
    	for (int i = 3, j = 0; j < 6; i++) {
    		seed[j] = b[i];
    		j++;
    	}
    	String seed2 = new String(seed);
    	ret = Strings.toInt(seed2) / 1000000;
    	seed = seed2.toCharArray();
    	for(int i = 0; i < 6; i++) if (seed[i] == '0') seed[i] = '2';
    	String seed3 = new String(seed);
    	long ret2 = Strings.toInt(seed3)/1000000;
    	semente = ret2 * ret2;
    	    	
    }

    /**
     * Retorna o �ltimo valor gerado.
     * Este m�todo pode ser chamado diversas vezes n�o
     * dever� ter seu valor alterado com exce��o se next() for invocado.
     *
     * @return double n�mero aleat�rio >= 0 e < 1
     */
    public double get() {
    	System.out.println(ret / 1000000.0);
      	return ret / 1000000.0;
    }
	
	
}
