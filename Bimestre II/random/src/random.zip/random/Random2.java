package random;

public class Random2 implements IRandom {
	
	private long semente;
	private long ret;
	
	public Random2() {
		semente = System.currentTimeMillis();
		String s = semente + "";
		char[] a = s.toCharArray();
		String b = "";
		for (int i = a.length - 6; i < a.length; i++) {
			b =  b + a[i];
		}
		semente = Strings.toInt(b);
	}
	
	public Random2 (long s) {
		String a = s + "";
		char[] b = a.toCharArray();
		if (b.length < 6) {
			char[] seed = new char[6];
			int i;
			for (i = 0; i < b.length; i++) seed[i] = b[i];
			for (; i < 6; i++) seed[i] = 7;
		}
		else {
			if (b.length == 6) {
				String x = "";
				for (int i = b.length-6; i < b.length; i++) {
					x =  x + b[i];
				}
				semente = Strings.toInt(x);
			}
		}
		
		
	}
	
	/**
     * Gera o pr�ximo n�mero aleat�rio.
     * O valor n�o � alterado at� esse m�todo ser invocado.
     */
	
    public void next() {
    	String a = semente + "";
    	System.out.println(a);
    	char[] b = a.toCharArray();
    	for (int i = 0; i < b.length; i++) if(b[i] == '0') b[i] = '1';
    	char[] seed = new char[3];
    	for (int i = b.length - 2, j = 2; j >= 0; i--, j--) seed[j] = b[i];
    	String seed2 = new String(seed);
    	ret = Strings.toInt(seed2);
    	semente = ret * ret;
    	    	
    }

    /**
     * Retorna o �ltimo valor gerado.
     * Este m�todo pode ser chamado diversas vezes n�o
     * dever� ter seu valor alterado com exce��o se next() for invocado.
     *
     * @return double n�mero aleat�rio >= 0 e < 1
     */
    public double get() {
    	System.out.println(ret / 1000.0);
      	return ret / 1000.0;
    }
	
	
}